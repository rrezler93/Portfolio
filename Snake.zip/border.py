from turtle import Turtle


class Border(Turtle):
    def __init__(self):
        super().__init__()
        self.width(2)
        self.color("white")
        self.penup()
        self.speed(5)
        self.left(90)
        self.forward(265)
        self.left(90)
        self.pendown()
        self.goto(0, 265)
        self.forward(265)
        self.left(90)
        self.forward(265 * 2)
        self.left(90)
        self.forward(265 * 2)
        self.left(90)
        self.forward(265 * 2)
        self.left(90)
        self.forward(265)
        self.hideturtle()
