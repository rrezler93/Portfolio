from turtle import *
import random


class Food(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.penup()
        self.shape()
        self.color("PowderBlue")
        self.speed("fastest")

    def refresh(self):
        random_x = random.randrange(-250, 250, 25)
        random_y = random.randrange(-250, 250, 25)
        self.goto(random_x, random_y)
