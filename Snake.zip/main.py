# Imports:
import time
from turtle import *
from snake import Snake
from food import Food
from scoreboard import Scoreboard
from border import Border

# Screen setup:
screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("DarkSeaGreen")
screen.title("My Snake Game")
screen.tracer(0)
border = Border()

# Objects:
snake = Snake()
food = Food()
scoreboard = Scoreboard()

# Keyboard functionality:
screen.listen()
screen.onkey(snake.up, "Up")
screen.onkey(snake.down, "Down")
screen.onkey(snake.left, "Left")
screen.onkey(snake.right, "Right")


# Valid food position:
def valid_position(food, snake):
    valid = True
    for segment in snake.segments:
        if food.distance(segment) < 15:
            valid = False
    return valid


# Place first food:
while not valid_position(food, snake):
    food.refresh()


# Starts game:
def play():
    game_over = False
    level = 0.3
    while not game_over:
        # Increase level:
        if len(snake.segments) > 18:
            level = 0.04
        elif len(snake.segments) > 16:
            level = 0.07
        elif len(snake.segments) > 13:
            level = 0.10
        elif len(snake.segments) > 11:
            level = 0.14
        elif len(snake.segments) > 9:
            level = 0.17
        elif len(snake.segments) > 7:
            level = 0.2
        elif len(snake.segments) > 5:
            level = 0.25

        screen.update()

        time.sleep(level)

        snake.move()

        # Food collision:
        if snake.head.distance(food) < 15:
            while not valid_position(food, snake):
                food.refresh()
            scoreboard.increase_score()
            snake.extend()

        # Wall collision:
        if snake.head.xcor() > 265 or snake.head.xcor() < -265 or snake.head.ycor() > 265 or snake.head.ycor() < -265:
            scoreboard.game_over()
            game_over = True

        # Tail collision:
        for segment in snake.segments[1:]:
            if snake.head.distance(segment) < 10:
                scoreboard.game_over()
                game_over = True


play()
screen.exitonclick()
