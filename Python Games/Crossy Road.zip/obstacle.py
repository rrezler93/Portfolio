from turtle import *
from random import *

class Obstacle:
    def __init__(self):
        self.segments = []
        self.coordinates = []

    def create_coordinates(self):
        x_coordinates = randrange(-250, 250, 25)
        y_coordinates = randrange(-250, 250, 25)
        self.coordinates.append((x_coordinates, y_coordinates))
        self.coordinates.append((x_coordinates + 25, y_coordinates))

    def create_obstacle(self):
        self.create_coordinates()
        for _ in self.coordinates:
            new_segment = Turtle("square")
            new_segment.setheading(180)
            new_segment.color("Burlywood")
            new_segment.penup()
            new_segment.goto(_)
            self.segments.append(new_segment)

    def create_outside_obstacle(self):
        self.create_obstacle()
        for _ in self.segments:
            _.setx(_.xcor() + 525)
            _.hideturtle()


    def move(self):
        self.segments[0].forward(25)
        self.segments[1].forward(25)

       # Show while in the border:
        if self.segments[0].xcor() < 260:
            self.segments[0].showturtle()
        if self.segments[1].xcor() < 260:
            self.segments[1].showturtle()

        # Hide after pass the border:
        if self.segments[0].xcor() < -250:
            self.segments[0].hideturtle()
        if self.segments[1].xcor() < -250:
            self.segments[1].hideturtle()

    def hide(self):
        for _ in self.segments:
            _.setx(-1000)
