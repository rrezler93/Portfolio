from turtle import *

class Player(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.penup()
        self.shape()
        self.color("white")
        self.speed("fastest")
        self.setheading(90)

    def refresh(self):
        self.goto(0, -279)

    def up(self):
        if self.ycor() < -250:
            self.goto(0, -250)
        elif self.ycor() == 250:
            self.goto(0, 282)
        else:
            self.forward(25)

    def down(self):
        if -225 <= self.ycor() < 251:
            self.backward(25)
