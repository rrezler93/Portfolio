# Imports:
from border import Border
from paddle import *
from ball import Ball
from scoreboard import Scoreboard
import time

# Screen setup:
screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("Thistle")
screen.title("Pong Game")
screen.tracer(0)

# Objects:
border = Border()
paddle1 = Paddle(paddle_1_position)
paddle2 = Paddle(paddle_2_position)
ball = Ball()
scoreboard = Scoreboard()

# Keyboard functionality:
screen.listen()
screen.onkey(paddle1.up, "w")
screen.onkey(paddle1.down, "s")
screen.onkey(paddle2.up, "p")
screen.onkey(paddle2.down, "l")


def paddle_collision():
    # First paddle:
    if ball.xcor() - 25 == paddle1.segments[0].xcor() and ball.ycor() == paddle1.segments[0].ycor() \
            or ball.xcor() - 25 == paddle1.segments[1].xcor() and ball.ycor() == paddle1.segments[1].ycor() \
            or ball.xcor() - 25 == paddle1.segments[2].xcor() and ball.ycor() == paddle1.segments[2].ycor():
        print("First paddle collision")
        return True
    # Second paddle:
    if ball.xcor() + 25 == paddle2.segments[0].xcor() and ball.ycor() == paddle2.segments[0].ycor() \
            or ball.xcor() + 25 == paddle2.segments[1].xcor() and ball.ycor() == paddle2.segments[1].ycor() \
            or ball.xcor() + 25 == paddle2.segments[2].xcor() and ball.ycor() == paddle2.segments[2].ycor():
        print("Second paddle collision")
        return True


def wall_colision():
    if ball.ycor() + 25 > 250 or ball.ycor() - 25 < -250:
        return True


# Starts game:
def play():
    game_over = False
    level = 0.2
    ball.reset()

    while not game_over:
        if scoreboard.player_1_score >= 2 or scoreboard.player_2_score >= 2:
            level = 0.1
        screen.update()
        time.sleep(level)
        ball.move()

        # Paddle collision:
        if paddle_collision():
            ball.bounce_paddle()

        # Wall collision:
        if wall_colision():
            ball.bounce_wall()

        # Score update:
        if ball.xcor() > 250:
            scoreboard.increase_player_1_score()
            # If score == 5, game over:
            if scoreboard.player_1_score == 5:
                game_over = True
                time.sleep(1)
                scoreboard.game_over()
                ball.hideturtle()
                screen.update()
                break
            ball.reset()
            paddle1.reset(paddle_1_position)
            paddle2.reset(paddle_2_position)
            time.sleep(1)
            screen.update()
            time.sleep(1)

        if ball.xcor() < -250:
            scoreboard.increase_player_2_score()
            # If score == 5, game over:
            if scoreboard.player_2_score == 5:
                game_over = True
                time.sleep(1)
                scoreboard.game_over()
                ball.hideturtle()
                screen.update()
                break
            ball.reset()
            paddle1.reset(paddle_1_position)
            paddle2.reset(paddle_2_position)
            time.sleep(1)
            screen.update()
            time.sleep(1)



play()
screen.exitonclick()
