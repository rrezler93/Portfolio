from turtle import Turtle


class Border(Turtle):
    def __init__(self):
        super().__init__()
        self.width(2)
        self.color("white")
        self.penup()
        self.left(90)
        self.forward(265)
        self.left(90)
        self.pendown()
        self.goto(0, 265)
        self.forward(265)
        self.left(90)
        self.forward(530)
        self.left(90)
        self.forward(530)
        self.left(90)
        self.forward(530)
        self.left(90)
        self.forward(265)
        self.left(90)
        self.forward(2)
        for _ in range(65):
            self.pendown()
            self.forward(4)
            self.penup()
            self.forward(4)
        self.pendown()
        self.forward(6)
        self.hideturtle()
