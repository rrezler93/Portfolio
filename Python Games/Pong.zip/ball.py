from turtle import *
from random import *


class Ball(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.penup()
        self.shape()
        self.color("white")
        self.previous_xcor = 0
        self.previous_ycor = 0
        self.new_xcor = 25
        self.new_ycor = 25

    def reset(self):
        new_ycor = randrange(-200, 200, 25)
        while new_ycor == 0:
            new_ycor = randrange(-200, 200, 25)
        self.goto(0, new_ycor)

    def bounce_paddle(self):
        if self.previous_xcor < self.xcor() and self.previous_ycor < self.ycor():
            self.new_xcor = -25
            self.new_ycor = 25
        elif self.previous_xcor < self.xcor() and self.previous_ycor > self.ycor():
            self.new_xcor = -25
            self.new_ycor = -25
        elif self.previous_xcor > self.xcor() and self.previous_ycor > self.ycor():
            self.new_xcor = 25
            self.new_ycor = -25
        elif self.previous_xcor > self.xcor() and self.previous_ycor < self.ycor():
            self.new_xcor = 25
            self.new_ycor = 25

    def bounce_wall(self):
        if self.previous_xcor > self.xcor() and self.previous_ycor < self.ycor():
            self.new_xcor = -25
            self.new_ycor = -25
        elif self.previous_xcor < self.xcor() and self.previous_ycor < self.ycor():
            self.new_xcor = 25
            self.new_ycor = -25
        elif self.previous_xcor > self.xcor() and self.previous_ycor > self.ycor():
            self.new_xcor = -25
            self.new_ycor = 25
        elif self.previous_xcor < self.xcor() and self.previous_ycor > self.ycor():
            self.new_xcor = 25
            self.new_ycor = 25

    def move(self):
        self.previous_xcor = self.xcor()
        self.previous_ycor = self.ycor()
        new_xcor = self.previous_xcor + self.new_xcor
        new_ycor = self.previous_ycor + self.new_ycor
        self.setposition(new_xcor, new_ycor)
