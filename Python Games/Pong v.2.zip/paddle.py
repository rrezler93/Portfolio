from turtle import *

paddle_1_position = [(-275, -25), (-275, 0), (-275, 25)]
paddle_2_position = [(275, -25), (275, 0), (275, 25)]
move_distance = 25


class Paddle:
    def __init__(self, coordinates):
        self.segments = []
        self.create_paddle(coordinates)

    def extend(self):
        self.add_segment(self.segments[-1].position())

    def add_segment(self, _):
        new_segment = Turtle("square")
        new_segment.color("white")
        new_segment.penup()
        new_segment.goto(_)
        new_segment.setheading(90)
        self.segments.append(new_segment)

    def move(self):
        if self.segments[0].ycor() < 205 and self.segments[2].ycor() > -205:
            for segment in range(len(self.segments)):
                self.segments[segment].forward(5)
                if self.segments[segment].xcor() % 1 != 0:
                    self.segments[segment].setx(round(self.segments[segment].xcor()))


    def create_paddle(self, coordinates):
        for _ in coordinates:
            self.add_segment(_)

    def up(self):
        if self.segments[-1].ycor() < 205:
            for segment in self.segments:
                segment.setheading(90)
                segment.forward(5)

    def down(self):
        if self.segments[0].ycor() > -205:
            for segment in self.segments:
                segment.setheading(270)
                segment.forward(5)


    def reset(self, coordinates):
        self.segments[0].setposition(coordinates[0])
        self.segments[1].setposition(coordinates[1])
        self.segments[2].setposition(coordinates[2])

