# Imports:
import time
from turtle import *
from border import Border
from player import Player
from level import Level
from obstacle import Obstacle

# Screen setup:
screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("LightBlue")
screen.title("Cross Road")
screen.tracer(0)
border = Border()

# Objects:
player = Player()
level = Level()

# Keyboard functionality:
screen.listen()
screen.onkey(player.up, "Up")
screen.onkey(player.down, "Down")

obstacles = []

def create_new_obstacle():
    obstacle = Obstacle()
    level.increase_level()
    print(obstacle.coordinates)
    obstacles.append(obstacle)


# Starts game:
def play():
    game_over = False
    refresh_rate = 0.15
    frame_no = -1

    player.refresh()
    screen.update()


    while not game_over:
        #Level:
        if level.level > 10:
            refresh_rate = 0.06
        elif level.level > 6:
            refresh_rate = 0.09
        elif level.level > 3:
            refresh_rate = 0.12
        else:
            pass

        # Create new obstacles every whole screen moved:
        frame_no += 1
        if frame_no % 10 == 0:
            create_new_obstacle()

        # Screen:
        screen.update()
        time.sleep(refresh_rate)

        player.down()

        # Move obstacle:
        for obstacle in obstacles:
            obstacle.move()

            # Game over:
            for segment in obstacle.segments:
                if segment.distance(player) < 20:
                    screen.onkey(None, "Up")
                    player.hideturtle()
                    segment.color("white")
                    screen.update()
                    game_over = True
                    break

    level.game_over()


play()
screen.exitonclick()
