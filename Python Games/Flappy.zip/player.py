from turtle import *

class Player(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.penup()
        self.shape()
        self.color("white")
        self.speed("fastest")
        self.setheading(90)

    def refresh(self):
        self.goto(-200, 0)

    def up(self):
        if self.ycor() == 250:
            pass
        elif self.ycor() == 225:
            self.forward(50)
        elif self.ycor() == 200:
            self.forward(75)
        else:
            self.forward(75)

    def down(self):
        if self.ycor() > -250:
            self.backward(25)
        else:
            pass
