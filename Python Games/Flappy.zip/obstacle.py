from turtle import *
from random import *

class Obstacle:
    def __init__(self):
        self.segments = []
        self.coordinates = []
        self.create_obstacle()

    def create_coordinates(self):
        y_pass_1 = randrange(-100, 200, 25)
        y_pass_2 = y_pass_1 - 25
        y_pass_3 = y_pass_2 - 25
        y_pass_4 = y_pass_3 - 25

        for _ in range(21):
            if (_ - 10) * 25 != y_pass_1 \
                    and (_ - 10) * 25 != y_pass_2 \
                    and (_ - 10) * 25 != y_pass_3 \
                    and (_ - 10) * 25 != y_pass_4:
                self.coordinates.append((275, (_ - 10) * 25))


    def create_obstacle(self):
        self.create_coordinates()
        for _ in self.coordinates:
            new_segment = Turtle("square")
            new_segment.setheading(180)
            new_segment.color("SteelBlue")
            new_segment.penup()
            new_segment.goto(_)
            new_segment.hideturtle()
            self.segments.append(new_segment)

    def move(self):
        for _ in self.segments:
            _.forward(25)

       # Show while in the border:
        for segment in self.segments:
            if segment.xcor() < 260:
                segment.showturtle()
            if segment.xcor() < 260:
                segment.showturtle()

            # Hide after pass the border:
            if segment.xcor() < -250:
                segment.hideturtle()
            if segment.xcor() < -250:
                segment.hideturtle()
