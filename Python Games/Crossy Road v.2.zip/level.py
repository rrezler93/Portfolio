from turtle import *

class Level(Turtle):
    def __init__(self):
        super().__init__()
        self.color("White")
        self.level = 1
        self.penup()
        self.goto(-218, 270)
        self.update_level()
        self.hideturtle()

    def game_over(self):
        self.goto(0, -291)
        self.write(f"Game over!", align="center", font=("Courier", 15, "bold"))

    def update_level(self):
        self.write(f"Level: {self.level}", align="center", font=("Courier", 15, "bold"))

    def increase_level(self):
        self.level += 1
        self.clear()
        self.update_level()
