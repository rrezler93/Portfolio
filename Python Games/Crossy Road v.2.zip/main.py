# Imports:
import time
from turtle import *
from border import Border
from player import Player
from level import Level
from obstacle import Obstacle

# Screen setup:
screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("Moccasin")
screen.title("Cross Road")
screen.tracer(0)
border = Border()

# Objects:
player = Player()
level = Level()

# Keyboard functionality:
screen.listen()
screen.onkey(player.up, "Up")
screen.onkey(player.down, "Down")

obstacles = []

def fill_new_level():
    for _ in range(25):
        obstacle = Obstacle()
        obstacle.create_obstacle()
        obstacles.append(obstacle)

def create_new_obstacles():
    for _ in range(25):
        obstacle = Obstacle()
        obstacle.create_outside_obstacle()
        obstacles.append(obstacle)


# Starts game:
def play():
    game_over = False
    refresh_rate = 0.04
    frame_no = 0

    fill_new_level()
    player.refresh()
    create_new_obstacles()

    while not game_over:

        # Create new obstacles every whole screen moved:
        if frame_no % 100 == 0:
            create_new_obstacles()
        frame_no += 1


        # Level:
        if level.level > 10:
            refresh_rate = 0.002
        elif level.level > 8:
            refresh_rate = 0.005
        elif level.level > 6:
            refresh_rate = 0.01
        elif level.level > 4:
            refresh_rate = 0.02
        elif level.level > 2:
            refresh_rate = 0.03

        # Screen:
        screen.update()
        time.sleep(refresh_rate)

        # Move obstacle:
        for obstacle in obstacles:
            obstacle.move()

            # Game over:
            for segment in obstacle.segments:
                if segment.distance(player) < 23:
                    screen.onkey(None, "Up")
                    screen.onkey(None, "Down")
                    segment.color("white")
                    screen.update()
                    game_over = True
                    break

        # Level completed:
        if player.ycor() > 270:
            screen.onkey(None, "Up")
            player.sety(282)
            screen.update()
            level.increase_level()
            time.sleep(2)
            player.refresh()

            # Clear obstacles:
            for obstacle in obstacles:
                obstacle.hide()
            obstacles.clear()

            fill_new_level()
            create_new_obstacles()
            screen.update()
            time.sleep(1)
            screen.onkey(player.up, "Up")

    level.game_over()


play()
screen.exitonclick()
